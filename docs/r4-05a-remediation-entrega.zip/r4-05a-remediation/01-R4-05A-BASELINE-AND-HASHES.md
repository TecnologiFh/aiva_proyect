# 01 — R4-05A Baseline y Hashes

**Orden:** `AIVA-SECURITY-R4-05A-VERIFIER-REMEDIATION-ORDER-01` · **Estado:** AUDITED / NOT APPLIED / NOT CERTIFIED

## 1. Identidad del checkout — **BLOCKED**

No tengo acceso al checkout `C:\xampp\htdocs\AIVA` ni a un entorno Git local (sandbox sin Git ni red de salida). Los siguientes datos deben completarse localmente por el owner:

| Dato | Estado | Valor |
|---|---|---|
| Ruta absoluta del repositorio | BLOCKED | (completar localmente) |
| Rama activa | BLOCKED | (debe ser `master`) |
| `git rev-parse HEAD` | BLOCKED | (debe ser `7cf6baf943b6ccdd78ef2d45a19761593f5c482e`) |
| `git status --short` inicial | BLOCKED | (debe estar limpio o justificado) |
| SHA-256 de `routes/web.php` desde Git | BLOCKED | `git show 7cf6baf:routes/web.php | sha256sum` |

## 2. Verificación remota realizada (solo lectura, sin checkout)

| Verificación | Resultado | Evidencia |
|---|---|---|
| Existencia del commit `7cf6baf…` en el remoto | **PASS** | El commit aparece en el historial público de `master` (autor luisfiestas123, 5 oct) |
| Existencia de `routes/web.php` en el remoto | **PASS** | GitHub Contents API, rama `master` |
| Tamaño del blob | **PASS** | 185.378 bytes (GitHub Contents API) |
| Git blob SHA-1 del archivo | **PASS** | `7ddb44283bfbe04e86a6d2fc38d002daa9bf326c` (GitHub Contents API) — equivale a `git hash-object routes/web.php` local |

> Nota: el SHA-256 no lo puedo calcular aquí sin los bytes locales. El valor del §1 debe obtenerse con el comando indicado y compararse antes de cualquier aplicación futura.

## 3. Hashes SHA-256 de los archivos recibidos en la entrega R4-05A

| Archivo | Bytes | SHA-256 |
|---|---|---|
| `02-routes-web.php.NUEVO` | 22174 | `322460b758ec9789a242eb3144d95f2e3e0fc425aa1a66d5150f511c5a9cc5e3` |
| `R4_05A_HttpAttackSurfaceContainmentTest.php` | 7429 | `d778968e244a2224b735fa4e894d0a22db410d1cc61cf6edb40d0c05731726d6` |
| `05-VERIFICAR-CANDIDATO.ps1` | 5479 | `f1db180e3bd9b609a61e285c748d80e99bc8972bef6394d6dd867dcd13963c02` |

## 4. Condiciones de aborto ejecutables aquí

- HEAD remoto ≠ baseline → los commits remotos más recientes (15 oct, autor TecnologiFh) son solo operaciones sobre documentos; el código baseline sigue siendo `7cf6baf`. Si tu HEAD local difiere, detente.
- Si `git show 7cf6baf:routes/web.php` falla → baseline no recuperable → detener (restricción 11).
- Si el tamaño local difiere de 185.378 B → discrepancia no explicada → detener y reportar.
