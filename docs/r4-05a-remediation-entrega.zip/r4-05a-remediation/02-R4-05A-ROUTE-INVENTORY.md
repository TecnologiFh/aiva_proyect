# 02 — R4-05A Inventario de Rutas Reconciliado

## 1. Reconciliación de cifras (criterio explícito)

| Categoría | Cifra | Criterio |
|---|---|---|
| URIs únicas retiradas | **59** | URIs distintas tras normalizar (sin slash inicial) |
| Definiciones de ruta retiradas en baseline | **59** | Una por URI: 54 `Route::get` + 5 `Route::match(['get','post'])` |
| Combinaciones método/URI retiradas | **64** | 54×(GET) + 5×(GET+POST) |
| URIs legítimas conservadas | 60 definiciones (post-deduplicación) | ver §3 |

**Descarte de cifras anteriores:** "57" (script PS1) y "72" (informe previo) fueron errores de conteo sin criterio explícito. Las cifras correctas son 59/59/64. Las 5 rutas `match(get,post)` son: `security-regression/run`, `governance-certification/run`, `tenant-ux-certification/run`, `production-security-audit/run`, `production-readiness/run`. `commerce-certification/run` es `Route::match` en baseline pero su vista queda conservada y su `run` se retira (1 definición).

## 2. Rutas retiradas (59) — método, controlador, middleware, riesgo

Middleware efectivo en todas: **ninguno** (grupo raíz `web` sin auth). "Middleware: —" = sin protección.

### 2.1 DDL / migraciones (8) — Riesgo: ejecución remota de DDL
| # | Método | URI | Tipo | Evidencia baseline |
|---|---|---|---|---|
| 1 | GET | `api/v1/p311-migrate-v1` | closure | `$migration->up()` directo (8 tablas) |
| 2 | GET | `api/v1/p311-migrate-v2` | closure | `ALTER TABLE catalog_versions ADD COLUMN` |
| 3 | GET | `api/v1/p312-migrate` | closure | migración P312 condicional |
| 4 | GET | `api/v1/f1-execute-migration` | closure | `require` + `$migrationObj->up()` |
| 5 | GET | `dev/migrate-m7` | closure | 4 migraciones Business |
| 6 | GET | `dev/migrate-m8` | closure | `enhance_orders_table_m8->up()` |
| 7 | GET | `dev/migrate-m10` | closure | **`DROP TABLE IF EXISTS customers`** |
| 8 | GET | `dev/migrate-pr14-pr23` | closure | 6 migraciones con ALTER |

### 2.2 Mutaciones globales / tenant literal (3) — Riesgo: integridad de datos
| # | Método | URI | Evidencia |
|---|---|---|---|
| 9 | GET | `api/v1/conversations/reset-all-ai` | `DB::table('conversations')->update(['mode'=>'AI'])` global |
| 10 | GET | `api/v1/sync-full-wallpa-catalog` | insert/update masivo con `tenant_id=11` literal, sin auth |
| 11 | GET | `api/v1/dev/sync-all-orders` | sincroniza pedidos del tenant 4 literal |

### 2.3 Exposición de logs/diagnóstico (6) — Riesgo: fuga de información
| # | Método | URI | Evidencia |
|---|---|---|---|
| 12 | GET | `api/v1/get-last-log` | últimas 60 líneas de `laravel.log` |
| 13 | GET | `api/v1/debug/last-orders` | últimos 10 pedidos sin tenant scope |
| 14 | GET | `api/v1/debug-wallpa-brasa` | diagnóstico tenant 11 + `opcache_reset()` |
| 15 | GET | `api/v1/dev/diagnose-media` | restaura archivos, muta MediaAsset/CommercialMedia |
| 16 | GET | `api/v1/debug-step-2` | `seedCanonicalTestData()` |
| 17 | GET | `api/v1/redis-runtime-gate` | estado de runtime Redis/infra público |

### 2.4 Suites/runners/certificaciones por HTTP (37) — Riesgo: mutación + superficie de ataque
Runners (18): `p312-verification-runner`, `conversational-t1-t6-runner`, `p311-verification-runner-v2`, `p311-e2e-business-runner`, `tci-verification-runner`, `p310-a-semantic-runner-v8`, `p310-b-runner-v1..v5` (5), `p310-a2-runner-v1..v5` (5), `p310-a1-runner-v2`, `p310/bloque-a1-test-runner`
Certificaciones con mutación (15): `payment-evidence/whatsapp-suite-v20` (DELETE/INSERT masivo), `review-suite-v7`, `fraud-suite-v4` (INSERT cross-tenant 99), `validation-suite-v10` (`updateOrInsert` en destinos de pago), `intake-suite-v2` (Storage+INSERT), `yape-suite-run`, `gold-dataset-v8`, `policy-suite-v5`, `master-certification-v1`, `orders/operational-truth-certification-v1`, `orders/context-integrity-certification` (+`-v3`,`-v5`,`-v12` con mode=migrate que crea tabla), `commerce-certification/run` (`transitionTo(STATE_CERTIFIED)` verificado en `CommerceCertificationReportController`)
Pruebas falsas/semilla: `payment-evidence/pi01-negative-paths` (PASS hardcodeado), `test-natural-conversation` (borra y simula 7 turnos; contiene secreto por defecto) = **2**
Pruebas falsas/semilla (2): `pi01-negative-paths` (PASS hardcodeado), `test-natural-conversation` (borra y simula 7 turnos; contiene el secreto del gateway por defecto).
Dev (2): `dev/certify-core-v21`, `dev/run-commerce-pilot`.
**Total 2.4 = 18+15+2+2 = 37. Suma general: 8+3+6+37+5 = 59 ✓**

### 2.5 Gates expuestos públicamente (5) — Riesgo: divulgación de postura de seguridad
| Método | URI |
|---|---|
| GET+POST | `api/v1/security-regression/run` |
| GET+POST | `api/v1/governance-certification/run` |
| GET+POST | `api/v1/tenant-ux-certification/run` |
| GET+POST | `api/v1/production-security-audit/run` |
| GET+POST | `api/v1/production-readiness/run` |

> Lista canónica completa de las 59 URIs: array `REMOVED_GET_URIS` del test R4_05A (59 entradas verificadas programáticamente).

## 3. Rutas legítimas conservadas (60 definiciones, deduplicadas)

Con middleware efectivo observado:

| Grupo | Middleware | Notas |
|---|---|---|
| `/health`, `/ready`, `/health/live`, `/health/ready` | — (público, contrato correcto) | readiness toca BD; ver F-07 |
| `/api/v1/commercial-media/{uuid}` | — | **F-01: exposición sin auth (pendiente)** |
| Auth (`/login`, `/logout` GET+POST, forgot/reset) | sesión web | GET /logout en F-04 |
| `/admin/*` (14 rutas) | `PlatformAdminMiddleware` | ver F-05 (auto-login en local) |
| `/api/v1/messaging/tenant-brain`, `qr-inbound` | `GatewayAuthMiddleware` | ver F-06 (secreto por defecto) |
| `/webhook*`, `/whatsapp/webhook*` | — | verificación Meta por token; POST sin auth = contrato webhook |
| Dashboard, operations, catalog, settings, business, crm, onboarding, knowledge, ai-playground | — (sin middleware de auth) | ver F-03: dependen de `requireActiveTenant()` |

## 4. Duplicados resueltos en el candidato

12 pares URI/destino idénticos definidos dos veces en baseline (Laravel resolvía al último): `/customers`, `/api/v1/crm/customers`, `/knowledge`, `/api/v1/business/knowledge-data`, `upload-source`, `sources/{id}/delete`, `knowledge-items/{id}/approve`, `.../reject`, `publish-catalog`, `/api/v1/operations/data`, `/api/v1/settings/hours`, `/api/v1/settings/payments`. El candidato conserva una sola definición por URI.

## 5. Advertencia metodológica (restricción de la orden)

La ausencia textual de una URI no prueba la ausencia de la operación: se verificó contra el registro del router Laravel (Fase E del test) y contra el inventario completo de closures baseline. No quedan closures dev no listados.
