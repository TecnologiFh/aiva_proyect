# 03 — R4-05A Hallazgos (F-01 a F-07) y Remediaciones Propuestas

**Método:** inspección de solo lectura del código real en `master` (mismos bytes que la baseline `7cf6baf` para estos archivos, verificado en sesión anterior). **Ningún archivo fue modificado.** Las remediaciones son propuestas: no aplicar sin orden posterior.

## F-01 — `GET /api/v1/commercial-media/{uuid}` — exposición de medios sin autorización

**Evidencia (closure en baseline):**
- Sirve el archivo **sin ningún middleware** y sin comprobar que el solicitante pertenezca al tenant del medio.
- `if ((int)$media->tenant_id === 11)` con arrays de cartas `1788557259_carta1.PNG` etc. — **tenant literal 11 (Wallpa) en código**.
- Efectos secundarios en un GET: `@mkdir($cardsDir, 0777, true)` y `@copy($source, $target)` — **creación de directorio con permisos 0777 y copia de archivos en cada petición**.
- `$candidates[] = $media->file_path` usado con `public_path()`/`storage_path()` — el `file_path` viene de BD; si un registro se poisona, hay riesgo de path traversal (archivo fuera del catálogo servido con `Content-Disposition: inline`).

**Riesgo:** exposición cross-tenant de medios comerciales (URLs filtradas por WhatsApp); escritura/lectura de disco con permisos amplios; superficie de path traversal.

**Remediación propuesta (compatible con contrato comercial):**
1. Resolver tenant del solicitante (sesión/gateway) y exigir `media.tenant_id === tenant solicitante`; 404 (no 403) si no coincide para no oracular existencia.
2. Eliminar la rama `tenant_id === 11`: parametrizar cartas por configuración del tenant (tabla/config), no por literales.
3. Quitar `mkdir 0777` → `0755` y mover la "garantía de aliases" a un comando Artisan (`media:ensure-aliases`) ejecutado en despliegue, no en GET.
4. Validar `file_path` contra un directorio raíz permitido (`realpath` + prefijo) antes de `response()->file`.

## F-02 — `POST /api/v1/dashboard/select-tenant` — validación real y estado global

**Evidencia (`UserTenantAccessService` + closure):**
- `setActiveTenantId()` **sí** llama a `validateTenantAccess()` — bien en principio.
- Pero `validateTenantAccess` apoya en `getAllowedTenants()`, y para no-superadmin hace `Auth::user()->tenant_id ?? session('active_tenant_id')`; **si ambos son null devuelve TODOS los tenants** (colección sin filtrar) → la validación queda vacía.
- `isSuperAdmin()` devuelve `true` si `request()->is('super-admin*') || request()->is('admin*')` — **cualquier petición a `/admin*` se trata como superadmin**.
- Fallbacks hardcodeados: si no hay tabla/tenants devuelve tenant **4 'Mi Negocio'**; `requireActiveTenant()` cae a `latest_active_tenant_id` y luego a default tenant `id != 4`, luego **5** — viola la doctrina "cero fallbacks" del Documento Maestro §9.1.
- La closure además hace `updateOrInsert(['setting_key' => 'latest_active_tenant_id'], ...)` — **una fila global única compartida por todos los usuarios/sesiones**: el último escritor fija el tenant activo de todos (contaminación cruzada).

**Riesgo:** selección de tenant arbitraria sin autenticación efectiva; fijación global de tenant entre usuarios.

**Remediación propuesta:**
1. Eliminar el fallback "todos los tenants" y los defaults 4/5: sin usuario+tenant resoluble → excepción controlada (fail-closed), no fallback.
2. Corregir `isSuperAdmin()`: nunca derivar privilegio del path de la petición; usar solo claim de sesión/rol verificado.
3. La persistencia del tenant activo debe ser **por usuario** (columna `users.active_tenant_id` o clave `tenant_settings` compuesta `user_id+setting_key`), nunca una fila global.

## F-03 — Autenticación/autorización de rutas de negocio — dependencia de `requireActiveTenant()`

**Evidencia:** rutas `/api/v1/business/*`, `/settings/*`, `/crm/*`, `/dashboard/*`, `/onboarding/*`, `/business-health/*`, `/catalog/*`, `/operations`, `/knowledge` **no tienen middleware `auth`** en el grupo `web`; los controladores resuelven tenant vía `requireActiveTenant()`. Como muestra F-02, para un usuario anónimo ese servicio puede devolver todos los tenants y **fijar sesión** — acceso cross-tenant sin login. Además (sesión anterior) `AuthenticationController` siembra en código **credenciales maestras** `admin@aiva.pe / Admin123!@#` y `donuts@fs.com / Donuts123!` con auto-reparación; y el `PlatformAdminMiddleware` trata como admin de plataforma al usuario con **`id === 1`** o email `@aiva.pe` (magic values).

**Riesgo:** acceso anónimo a datos de negocio de cualquier tenant; credenciales maestras versionadas.

**Remediación propuesta (fase IAM posterior a R4-05, fuera del alcance de esta orden):**
1. Añadir middleware `auth` al grupo de rutas de negocio y hacer `requireActiveTenant()` estrictamente fail-closed.
2. Mover credenciales semilla a seeds interactivos/secretos, nunca en controladores; eliminar auto-reparación de credenciales.
3. Eliminar privilegio por `id===1`/dominio de email; usar capability/rol persistedo.

## F-04 — Métodos HTTP inapropiados para mutaciones

**Evidencia:**
- `GET /logout` — destruye sesión vía GET.
- `knowledge-items/approve-all`, `knowledge-items/{id}/approve`, `.../reject` usan `Route::match(['get','post'],...)` — **mutaciones aceptadas por GET**.
- CSRF: las rutas POST del grupo `web` pasan `VerifyCsrfToken` (correcto); las mutaciones GET lo eluden por diseño — por eso importa quitar GET.

**Remediación propuesta (mínima, compatible con interfaces):**
1. `Route::post('/logout', ...)` y eliminar el GET; actualizar la plantilla del menú (formulario POST con `@csrf`).
2. Cambiar approve/reject/approve-all a `Route::post` y ajustar las llamadas del frontend (fetch POST con token CSRF).

## F-05 — Control Plane `/admin` — contrato de respuestas y backdoor de entorno local

**Evidencia (`PlatformAdminMiddleware`):**
- Anónimo no-AJAX → **302** a `/login`; anónimo AJAX → **401**; autenticado sin rol plataforma → **403**. (El test debe aceptar este contrato, no forzar un único código.)
- **Auto-login en `local`:** si no hay usuario y `app()->environment('local')`, hace `firstOrCreate` de un admin de plataforma (`admin@aiva.com`) y `Auth::guard('platform')->login($user)`.
- Trata como admin de plataforma a `id === 1` y emails `@aiva.pe`.

**Riesgo:** bypass completo de autenticación en cualquier despliegue con `APP_ENV=local`; magic-user-id.

**Remediación propuesta:** eliminar el auto-login (o protegerlo con un flag explícito `AIVA_ALLOW_LOCAL_ADMIN` default-off y solo en local); eliminar `id===1`; credenciales seed solo vía `db:seed` documentado.

## F-06 — Gateway de mensajería — secreto versionado y transporte

**Evidencia (verificada en lectura anterior de `GatewayAuthMiddleware.php`):**
- `env('AIVA_GATEWAY_SECRET', 'aiva_qr_gateway_master_secret_2026')` — **secreto por defecto versionado en el código**.
- Acepta el secreto por **query string** (`?gateway_secret=`), no solo header — queda en logs de acceso e historiales.
- (De la ruta `test-natural-conversation`, hoy retirada: el mismo default aparecía en closure — vía de fuga eliminada con R4-05A.)

**Riesgo:** cualquie
r que lea el repo conoce el secreto de producción; fuga vía query en logs.

**Remediación propuesta (Bloque C, orden posterior):** quitar el default (fail-closed si no configurado); aceptar solo header; rotar el secreto en gateway y `.env`.

## F-07 — Salud y funcionalidad legítima — doble implementación de readiness

**Evidencia:**
- `/health` y `/ready` → `HealthController` (liveness: estático sin BD; **readiness: consulta BD** `Schema::hasTable('products')`, `DB::select('select 1')`).
- `/health/live`, `/health/ready` → `ProductionHealthService` — **implementación distinta e independiente** del `HealthController`. Dos readiness divergentes = señal contradictoria en producción.

**Riesgo:** readiness inconsistente según el endpoint consultado; readiness ligado a la BD de negocio (aceptable en prod, pero en tests exige la BD aislada).

**Remediación propuesta:** unificar ambos en un único `HealthService` inyectado; liveness sin BD (correcto hoy), readiness con timeouts y sin detalles internos en la respuesta pública.

---
**Resumen:** 7 hallazgos con evidencia. Ninguno resuelto (esta orden no autoriza aplicar). F-01/F-02/F-03 son los de mayor severidad (acceso cross-tenant potencialmente anónimo). Los Bloques R4-05B/C deberán abordar F-01 y F-06 respectivamente; F-02/F-03/F-04/F-05/F-07 requieren una fase IAM/hardening posterior.
