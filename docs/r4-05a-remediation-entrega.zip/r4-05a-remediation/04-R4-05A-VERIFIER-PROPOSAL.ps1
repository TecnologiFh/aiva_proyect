#requires -version 5
<#
.SYNOPSIS
  R4-05A — Verificador propuesto (remediación). Genera y valida 06-R4-05A-PATCH-CANDIDATE.patch.
.DESCRIPTION
  Fases: A) aborto por baseline · B) validación estructural (php -l si existe) · C) comparación
  textual auxiliar · D) generación de parche con rutas a/routes/web.php b/routes/web.php ·
  E) git apply --check en índice temporal · F) verificación de alcance (solo routes/web.php).
  Nunca modifica el checkout. Cualquier fallo crítico = exit 1 (abortar, continuar prohibido).
.NOTAS
  Ejecutar desde la raíz del repo:  powershell -File 04-R4-05A-VERIFIER-PROPOSAL.ps1 -Candidate .\02-routes-web.php.NUEVO
#>
param(
  [Parameter(Mandatory=$true)][string]$Candidate,
  [string]$Baseline = "7cf6baf943b6ccdd78ef2d45a19761593f5c482e",
  [string]$PatchOut = "06-R4-05A-PATCH-CANDIDATE.patch"
)
$ErrorActionPreference = "Stop"
$script:failures = 0
function Fail($msg) { Write-Host "FAIL $msg" -ForegroundColor Red; $script:failures++; throw "ABORT: $msg" }
function Check($cond, $msg) { if ($cond) { Write-Host "OK   $msg" -ForegroundColor Green } else { Fail $msg } }

# ---------- FASE A: baseline y aborto ----------
Check (Test-Path .git) "estamos en la raíz de un repositorio Git"
$head = (git rev-parse HEAD).Trim()
Check ($head -eq $Baseline) "HEAD coincide con la baseline $Baseline (actual: $head)"
$branch = (git rev-parse --abbrev-ref HEAD).Trim()
Write-Host "INFO rama=$branch"
$dirty = git status --porcelain
if ($dirty) { Write-Host "WARN working tree con cambios:" -ForegroundColor Yellow; $dirty | ForEach-Object { Write-Host "     $_" } }

# Recuperar baseline EXCLUSIVAMENTE desde el objeto Git (no del working tree)
$origTmp = New-TemporaryFile
git show "${Baseline}:routes/web.php" | Out-File -Encoding utf8 $origTmp
if ($LASTEXITCODE -ne 0) { Fail "no se pudo recuperar ${Baseline}:routes/web.php del objeto Git" }
$origHash = (git hash-object $origTmp).Trim()
$baselineHash = (git rev-parse "${Baseline}:routes/web.php").Trim()
Check ($origHash -eq $baselineHash) "baseline recuperada es byte-idéntica al objeto Git ($baselineHash)"

# Hash SHA-256 de referencia (para el informe)
$sha256 = [System.Security.Cryptography.SHA256]::Create()
$origBytes = [System.IO.File]::ReadAllBytes($origTmp)
Write-Host ("INFO SHA-256 baseline: {0}" -f ([BitConverter]::ToString($sha256.ComputeHash($origBytes)).Replace("-","").ToLower())

# ---------- FASE B: validez estructural ----------
Check (Test-Path $Candidate) "candidato existe y es legible"
$candBytes = [System.IO.File]::ReadAllBytes($Candidate)
Check ($candBytes.Length -gt 100) "candidato no está vacío ($($candBytes.Length) B)"
Check ($candBytes[0] -eq 0x3C -and $candBytes[1] -eq 0x3F) "candidato comienza con '<?'"
Check (-not ($candBytes[0] -eq 0xEF)) "candidato sin BOM"
$php = Get-Command php -ErrorAction SilentlyContinue
if ($php) {
  & php -l $Candidate | Out-Null
  Check ($LASTEXITCODE -eq 0) "php -l: sintaxis válida"
  & php -l routes/web.php | Out-Null
  Check ($LASTEXITCODE -eq 0) "php -l: baseline sintácticamente válida"
} else {
  Write-Host "BLOCKED php -l: binario php no disponible en PATH" -ForegroundColor Yellow
}

# ---------- FASE C: comparación textual AUXILIAR (no prueba equivalencia) ----------
$orig = [System.IO.File]::ReadAllText($origTmp)
$cand = [System.IO.File]::ReadAllText($Candidate)
$origLines = ($orig -split "`n") | ForEach-Object { $_.Trim() }
$routeRe = '^\s*Route::'
$candRouteLines = ($cand -split "`n") | Where-Object { $_ -match $routeRe } | ForEach-Object { $_.Trim() }
$missing = @($candRouteLines | Where-Object { $origLines -notcontains $_ })
Check ($missing.Count -eq 0) "auxiliar: $($candRouteLines.Count) definiciones del candidato existen en baseline (no encontradas: $($missing.Count))"

# ---------- FASE D: generación del parche ----------
# git diff --no-index con prefijos explícitos; rutas temporales renombradas al destino real
$candTmp = New-TemporaryFile
Copy-Item $Candidate $candTmp -Force
$raw = git diff --no-index --src-prefix=a/ --dst-prefix=b/ -- "$origTmp" "$candTmp"
$patch = ($raw -join "`n") -creplace [regex]::Escape("a/$origTmp"), "a/routes/web.php" -creplace [regex]::Escape("b/$candTmp"), "b/routes/web.php"
# Encabezados estándar de diff Git para git apply
$patch = $patch -creplace '(?m)^diff --git a/[^\s]+ b/[^\s]+', 'diff --git a/routes/web.php b/routes/web.php'
$patch = $patch -creplace '(?m)^index [0-9a-f]+\.\.[0-9a-f]+', ''
[System.IO.File]::WriteAllText($PatchOut, $patch, (New-Object System.Text.UTF8Encoding($false)))
Check (Test-Path $PatchOut) "parche escrito: $PatchOut ($((Get-Item $PatchOut).Length) B)"
Check (-not ([System.IO.File]::ReadAllBytes($PatchOut)[0] -eq 0xEF)) "parche sin BOM"

# ---------- FASE E: aplicabilidad en índice temporal (no checkout) ----------
$indexTmp = New-TemporaryFile
git read-tree $Baseline
if ($LASTEXITCODE -ne 0) { Fail "read-tree de la baseline" }
git apply --cached --check $PatchOut 2>$null
$cachedCheck = $LASTEXITCODE
git apply --check $PatchOut 2>$null
$wtCheck = $LASTEXITCODE
Check ($wtCheck -eq 0) "git apply --check contra working tree limpio de baseline"
Write-Host "INFO git apply --cached --check (índice temporal): exit=$cachedCheck"

# ---------- FASE F: alcance ----------
$filesInPatch = [regex]::Matches($patch, '(?m)^diff --git a/(\S+) b/(\S+)') | ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique
Check ($filesInPatch.Count -eq 1 -and $filesInPatch[0] -eq "routes/web.php") "el parche solo toca routes/web.php (encontrados: $($filesInPatch -join ', '))"
$addedSuites = [regex]::Matches($patch, '(?m)^\+.*(Route::|Schema::|DB::(statement|unprepared))') | Where-Object { $_.Value -notmatch '^\+\+\+' }
Write-Host "INFO líneas añadidas con Route::/Schema::/DB::statement en el parche: $($addedSuites.Count) (esperado: 0 — cambio de solo eliminación/dedup)"

Remove-Item $origTmp,$candTmp,$indexTmp -Force -ErrorAction SilentlyContinue
if ($script:failures -gt 0) { Write-Host "VERIFICACION FALLIDA" -ForegroundColor Red; exit 1 }
Write-Host "VERIFICACION SUPERADA — parche listo para revisión humana del diff completo" -ForegroundColor Green
