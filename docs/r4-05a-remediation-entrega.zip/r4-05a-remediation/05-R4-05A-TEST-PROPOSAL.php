<?php

namespace Tests\Feature\Security;

use Illuminate\Support\Facades\Route;
use Tests\TestCase;

/**
 * R4-05A — HTTP Attack Surface Containment (propuesta de corrección).
 * Orden: AIVA-SECURITY-R4-05A-VERIFIER-REMEDIATION-ORDER-01 (Fase E).
 *
 * Principios:
 *  - El router de Laravel es la fuente de verdad (no cadenas en fuente).
 *  - Un 404 es necesario pero no suficiente: también se afirma que la ruta
 *    NO está registrada y que ningún método la expone.
 *  - Chequeos de middleware contra las rutas registradas.
 *  - Contratos de seguridad reales por endpoint (F-05/F-06), sin forzar
 *    códigos artificiales.
 *  - Sin persistencia: el test no escribe en BD (router + kernel HTTP).
 */
class R4_05A_HttpAttackSurfaceContainmentTest extends TestCase
{
    /** URIs retiradas (59). */
    private const REMOVED_URIS = [
        'api/v1/p311-migrate-v1', 'api/v1/p311-migrate-v2', 'api/v1/get-last-log',
        'api/v1/debug-step-2', 'api/v1/p312-migrate', 'api/v1/p312-verification-runner',
        'api/v1/conversational-t1-t6-runner', 'api/v1/dev/diagnose-media',
        'api/v1/p311-verification-runner-v2', 'api/v1/p311-e2e-business-runner',
        'api/v1/debug-wallpa-brasa', 'api/v1/sync-full-wallpa-catalog',
        'api/v1/test-natural-conversation', 'api/v1/tci-verification-runner',
        'api/v1/p310-a-semantic-runner-v8', 'api/v1/p310-b-runner-v5', 'api/v1/p310-b-runner-v4',
        'api/v1/p310-b-runner-v3', 'api/v1/p310-b-runner-v2', 'api/v1/p310-b-runner-v1',
        'api/v1/p310-a2-runner-v5', 'api/v1/p310-a2-runner-v4', 'api/v1/p310-a2-runner-v3',
        'api/v1/p310-a2-runner-v2', 'api/v1/p310-a2-runner-v1', 'api/v1/p310-a1-runner-v2',
        'api/v1/p310/bloque-a1-test-runner', 'api/v1/payment-evidence/master-certification-v1',
        'api/v1/orders/operational-truth-certification-v1',
        'api/v1/orders/context-integrity-certification-v3',
        'api/v1/orders/context-integrity-certification-v5',
        'api/v1/orders/context-integrity-certification',
        'api/v1/orders/context-integrity-certification-v12',
        'api/v1/debug/last-orders', 'api/v1/f1-execute-migration',
        'api/v1/payment-evidence/gold-dataset-v8', 'api/v1/payment-evidence/pi01-negative-paths',
        'api/v1/payment-evidence/whatsapp-suite-v20', 'api/v1/payment-evidence/review-suite-v7',
        'api/v1/payment-evidence/policy-suite-v5', 'api/v1/payment-evidence/fraud-suite-v4',
        'api/v1/payment-evidence/validation-suite-v10', 'api/v1/payment-evidence/yape-suite-run',
        'api/v1/payment-evidence/intake-suite-v2', 'api/v1/dev/sync-all-orders',
        'api/v1/conversations/reset-all-ai', 'api/v1/redis-runtime-gate',
        'dev/migrate-m7', 'dev/migrate-m8', 'dev/migrate-m10', 'dev/migrate-pr14-pr23',
        'dev/certify-core-v21', 'dev/run-commerce-pilot', 'api/v1/commerce-certification/run',
        'api/v1/security-regression/run', 'api/v1/governance-certification/run',
        'api/v1/tenant-ux-certification/run', 'api/v1/production-security-audit/run',
        'api/v1/production-readiness/run',
    ];

    /** Rutas retiradas que aceptaban también POST. */
    private const REMOVED_WITH_POST = [
        'api/v1/security-regression/run', 'api/v1/governance-certification/run',
        'api/v1/tenant-ux-certification/run', 'api/v1/production-security-audit/run',
        'api/v1/production-readiness/run',
    ];

    /** @test Las URIs retiradas no están registradas para ningún método. */
    public function removed_routes_are_not_registered(): void
    {
        $routes = Route::getRoutes();
        foreach (self::REMOVED_URIS as $uri) {
            foreach ($routes->getRoutes() as $route) {
                $this->assertNotSame($uri, $route->uri(), "La URI /{$uri} sigue registrada (métodos: {$route->methods()}).");
            }
        }
    }

    /** @test Las URIs retiradas responden 404 por GET y, si aplicaba, por POST. */
    public function removed_routes_respond_404_all_methods(): void
    {
        foreach (self::REMOVED_URIS as $uri) {
            $this->get('/' . $uri)->assertNotFound();
        }
        foreach (self::REMOVED_WITH_POST as $uri) {
            $this->post('/' . $uri)->assertNotFound();
        }
    }

    /** @test El gateway exige credencial (contrato F-06). */
    public function gateway_requires_credentials(): void
    {
        $this->post('/api/v1/messaging/qr-inbound', [
            'gateway_session_id' => 'test-session',
            'phone' => '51999000111',
            'message' => 'hola',
        ])->assertStatus(401);
    }

    /** @test Contrato F-05: /admin nunca 200 para anónimo (302 web o 401 AJAX). */
    public function admin_control_plane_contract_for_anonymous(): void
    {
        $this->assertNotSame(200, $this->get('/admin')->getStatusCode());
        $this->assertContains($this->get('/admin')->getStatusCode(), [302, 401]);
        $this->get('/admin', ['Accept' => 'application/json'])->assertStatus(401);
    }

    /** @test Middleware efectivo en rutas protegidas registradas. */
    public function protected_routes_have_middleware(): void
    {
        $byUri = collect(Route::getRoutes()->getRoutes())->keyBy(fn ($r) => $r->uri());
        $admin = $byUri->get('admin/tenants');
        $this->assertNotNull($admin, 'La ruta admin/tenants debe seguir registrada.');
        $this->assertContains('App\Shared\Middleware\PlatformAdminMiddleware', $admin->gatherMiddleware());
        $gateway = $byUri->get('api/v1/messaging/qr-inbound');
        $this->assertNotNull($gateway, 'La ruta qr-inbound debe seguir registrada.');
        $this->assertContains('App\Shared\Middleware\GatewayAuthMiddleware', $gateway->gatherMiddleware());
    }

    /** @test Rutas legítimas conservadas (regresión de enrutamiento). */
    public function legitimate_routes_remain(): void
    {
        $uris = collect(Route::getRoutes()->getRoutes())->map(fn ($r) => $r->uri())->all();
        foreach ([
            'login', 'dashboard', 'catalog', 'operations', 'customers', 'knowledge',
            'commerce-certification', 'api/v1/commercial-media/{uuid}', 'api/v1/messaging/qr-inbound',
            'api/v1/dashboard/conversations', 'api/v1/business/knowledge-data', 'webhook', 'admin',
        ] as $uri) {
            $this->assertContains($uri, $uris, "La ruta legítima /{$uri} dejó de estar registrada.");
        }
    }

    /** @test Salud pública disponible. */
    public function health_endpoints_public(): void
    {
        $this->get('/health')->assertOk();
        $this->get('/health/live')->assertOk();
    }

    /** @test No hay operaciones de escritura servidas por GET en las rutas conservadas (F-04 parcial). */
    public function no_get_write_operations_in_kept_routes(): void
    {
        $writePatterns = ['save', 'approve', 'reject', 'publish', 'archive', 'restore', 'delete', 'toggle', 'update', 'reset', 'sync', 'select-tenant'];
        foreach (Route::getRoutes()->getRoutes() as $route) {
            if (!in_array('GET', $route->methods())) {
                continue;
            }
            foreach ($writePatterns as $p) {
                $this->assertStringNotContainsString($p, strtolower($route->uri()),
                    "Operación de escritura potencial '{$p}' servida por GET: /{$route->uri()}");
            }
        }
    }
}
